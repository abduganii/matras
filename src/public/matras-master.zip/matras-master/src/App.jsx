import React from 'react'
import Routes from './router/route'

const App = () => {
  return (
    <Routes/>
  )
}

export default App